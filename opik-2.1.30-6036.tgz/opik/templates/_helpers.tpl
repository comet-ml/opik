{{/*
Expand the name of the chart.
*/}}
{{- define "opik.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "opik.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "opik.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "opik.labels" -}}
{{ include "opik.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "opik.clickhouse.labels" -}}
{{ include "opik.clickhouse.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}
{{/*
Selector labels
*/}}
{{- define "opik.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opik.name" $ }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
{{- define "opik.clickhouse.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opik.name" $ }}
app.kubernetes.io/instance: {{ .Release.Name }}
component: clickhouse
# app.kubernetes.io/component: clickhouse
{{- end }}

{{/*
{{- end }}
{{/*
Create the name of the service account to use
*/}}
{{- define "opik.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "opik.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
{{/*
Create the name of the service account to use
*/}}
{{- define "clickhouse.serviceAccountName" -}}
{{- if .Values.clickhouse.serviceAccount.create }}
{{- default (include "opik.fullname" .) .Values.clickhouse.serviceAccount.name }}
{{- else }}
{{- default "default" (include "opik.serviceAccountName" .) }}
{{- end }}
{{- end }}
{{/*
Create the name of the service account to use
*/}}
{{- define "clickhouse.backup.serviceAccountName" -}}
{{- if .Values.clickhouse.backup.serviceAccount.create }}
{{- default (include "clickhouse.serviceAccountName" .) .Values.clickhouse.backup.serviceAccount.name }}
{{- else }}
{{- default "default" (include "clickhouse.serviceAccountName" .) }}
{{- end }}
{{- end }}
{{/*
Create the name of the service account to use
*/}}
{{- define "service.serviceAccountName" -}}
{{- if .serviceAccount.create }}
{{- default ( cat .serviceName "-sa" | nospace ) .serviceAccount.name }}
{{- else }}
{{- default "default" .serviceAccount.name }}
{{- end }}
{{- end }}
{{/*
Generate Content-Security-Policy header value from CSP configuration
Usage: {{ include "opik.cspHeaderValue" .Values.component.frontend.contentSecurityPolicy }}
Returns: "default-src 'self'; script-src 'self' 'unsafe-inline'"
Note: Directives are sorted alphabetically to ensure deterministic output
*/}}
{{- define "opik.cspHeaderValue" -}}
{{- if . -}}
{{-   $cspParts := list -}}
{{-   $cspMap := . -}}
{{-   $sortedKeys := keys . | sortAlpha -}}
{{-   range $sortedKeys -}}
{{-     $directive := . -}}
{{-     $sources := index $cspMap $directive -}}
{{-     $cspParts = append $cspParts (printf "%s %s" $directive (join " " $sources)) -}}
{{-   end -}}
{{-   join "; " $cspParts -}}
{{- end -}}
{{- end -}}

{{/*
Renders a container probe (liveness / readiness / startup) from a probe spec.
Supports two shapes for the same spec:
  1. Simplified path/port: BOTH `path` and `port` must be set. The remaining
     probe fields (timeoutSeconds, periodSeconds, initialDelaySeconds,
     successThreshold, failureThreshold) are each honored if the caller sets
     them, otherwise fall back to defaults (2 / 10 / 0 / 1 / 2). This is a
     common case for HTTP probes.
     (Setting only one of `path`/`port` is a misconfiguration — provide both,
     or use a full probe spec below.)
  2. Full definition: any other spec is emitted verbatim, so values.yaml can
     define httpGet/exec/tcpSocket plus any probe timing fields directly.
Usage:
{{- include "opik.probe" $value.livenessProbe | nindent 12 }}
*/}}
{{- define "opik.probe" -}}
{{- if and .path .port }}
{{- /* Backward compatibility: simplified path/port definition */}}
httpGet:
  path: {{ .path }}
  port: {{ .port }}
  httpHeaders:
    - name: Accept
      value: application/json
timeoutSeconds: {{ .timeoutSeconds | default 2 }}
periodSeconds: {{ .periodSeconds | default 10 }}
initialDelaySeconds: {{ .initialDelaySeconds | default 0 }}
successThreshold: {{ .successThreshold | default 1 }}
failureThreshold: {{ .failureThreshold | default 2 }}
{{- else }}
{{- /* Full probe definition from values.yaml */}}
{{- toYaml . }}
{{- end }}
{{- end -}}

{{/*
Renders a value that contains template perhaps with scope if the scope is present.
Usage:
{{ include "common.tplvalues.render" (dict "value" .Values.path.to.value "context" $) }}
*/}}
{{- define "common.tplvalues.render" -}}
{{- $value := typeIs "string" .value | ternary .value (.value | toYaml) }}
{{- if contains "{{" (toJson .value) }}
  {{- if .scope }}
      {{- tpl (cat "{{- with $.RelativeScope -}}" $value "{{- end }}") (merge (dict "RelativeScope" .scope) .context) }}
  {{- else }}
    {{- tpl $value .context }}
  {{- end }}
{{- else }}
    {{- $value }}
{{- end }}
{{- end -}}
