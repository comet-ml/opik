# Changelog

All notable changes to this chart will be documented in this file.

## [0.5.5] - 2026-02-06

- Update charts/zookeeper/values.yaml zookeeper (#979) ([c2658505](https://github.com/CloudPirates-io/helm-charts/commit/c2658505))
- [all]: Update documentation to include proper cosign public key ([e42365dc](https://github.com/CloudPirates-io/helm-charts/commit/e42365dc))

## [0.5.4] - 2026-02-01

- Use latest common version (#934) ([b7f36a24](https://github.com/CloudPirates-io/helm-charts/commit/b7f36a24))
- [all]: Update every chart to newest common (#920) ([f8d134d5](https://github.com/CloudPirates-io/helm-charts/commit/f8d134d5))

## [0.5.3] - 2026-01-28

- Add support for overriding selector labels (#915) ([a2cd8519](https://github.com/CloudPirates-io/helm-charts/commit/a2cd8519))

## [0.5.2] - 2026-01-19

- Update charts/zookeeper/values.yaml zookeeper (#858) ([7dceb5c1](https://github.com/CloudPirates-io/helm-charts/commit/7dceb5c1))

## [0.5.1] - 2026-01-08

- [zookeeper]: fix NetPol and PDB to use correct selectorLabels template (#802) ([7e578e35](https://github.com/CloudPirates-io/helm-charts/commit/7e578e35))

## [0.5.0] - 2026-01-05

- [zookeeper]: add ServiceMonitor (#792) ([3831796b](https://github.com/CloudPirates-io/helm-charts/commit/3831796b))

## [0.4.1] - 2026-01-01

- [zookeeper]: fix typos and set automountServiceAccountToken to false (#789) ([343fb3d8](https://github.com/CloudPirates-io/helm-charts/commit/343fb3d8))

## [0.3.10] - 2025-12-23

- Final fix for supporting migration from bitnami zookeeper (#778) ([474ab064](https://github.com/CloudPirates-io/helm-charts/commit/474ab064))

## [0.3.9] - 2025-12-23

- fix(zookeeper): add apiVersion and kind to volumeClaimTemplates to prevent OutOfSync on Server-Side-Apply with ArgoCD (#777) ([6800e292](https://github.com/CloudPirates-io/helm-charts/commit/6800e292))

## [0.3.8] - 2025-12-21

- Add support for Bitnami Zookeeper migration with multiple replicas (#768) ([65c0764b](https://github.com/CloudPirates-io/helm-charts/commit/65c0764b))

## [0.3.7] - 2025-12-17

- Add dataDir option to override path to data folder (#763) ([092def6e](https://github.com/CloudPirates-io/helm-charts/commit/092def6e))

## [0.3.6] - 2025-12-11

- [redis, valkey,rabbitmq,zookeeper]: allow setting revisionHistoryLimit (#725) ([ac9e1ba9](https://github.com/CloudPirates-io/helm-charts/commit/ac9e1ba9))

## [0.3.5] - 2025-12-06

- Update zookeeper statefulset to use existing peristent volume claim if set (#698) ([1bf19924](https://github.com/CloudPirates-io/helm-charts/commit/1bf19924))

## [0.3.4] - 2025-12-04

- fix network policy switch (#690) ([f7b8ae2f](https://github.com/CloudPirates-io/helm-charts/commit/f7b8ae2f))

## [0.3.3] - 2025-12-01

- [universal] add labels to statefulset pvc-templates (#681) ([87624a55](https://github.com/CloudPirates-io/helm-charts/commit/87624a55))
- Update charts/zookeeper/values.yaml zookeeper (#604) ([25861908](https://github.com/CloudPirates-io/helm-charts/commit/25861908))

## [0.3.2] - 2025-11-13

- [universal] update readme files (#583) ([e63f5f94](https://github.com/CloudPirates-io/helm-charts/commit/e63f5f94))

## [0.3.1] - 2025-11-12

- Update charts/zookeeper/values.yaml zookeeper (#590) ([ac259f3b](https://github.com/CloudPirates-io/helm-charts/commit/ac259f3b))
- [etcd, rabbitmq, redis, zookeeper] add signature verification documentation to readme (#476) ([91c73105](https://github.com/CloudPirates-io/helm-charts/commit/91c73105))

## [0.3.0] - 2025-10-28

- [universal] unify extraEnvVars in all charts (#477) ([4aee7b4a](https://github.com/CloudPirates-io/helm-charts/commit/4aee7b4a))

## [0.2.1] - 2025-10-23

- [universal] Update annotations, labels, podannotations and podlabel (#454) ([cdb38db9](https://github.com/CloudPirates-io/helm-charts/commit/cdb38db9))
- [universal] fix all appversions in charts (#417) ([b8debebf](https://github.com/CloudPirates-io/helm-charts/commit/b8debebf))
- [universal] use a string instead of a boolean (#413) ([c24d26d6](https://github.com/CloudPirates-io/helm-charts/commit/c24d26d6))
- [universal] improve chart artifact annotations (#404) ([37f1c5be](https://github.com/CloudPirates-io/helm-charts/commit/37f1c5be))
- [universal] Rework all schema json (#393) ([79d1439f](https://github.com/CloudPirates-io/helm-charts/commit/79d1439f))
- [mariadb] add galera cluster support for mariadb (#348) ([b7a63ee8](https://github.com/CloudPirates-io/helm-charts/commit/b7a63ee8))

## [0.2.0] - 2025-10-14

- Update chart.yaml dependencies for indepentent charts (#382) ([87acfb14](https://github.com/CloudPirates-io/helm-charts/commit/87acfb14))

## [0.1.7] - 2025-10-13

- [universal] Fix imagepullsecret in vales.schema.json (#374) ([bcc566c2](https://github.com/CloudPirates-io/helm-charts/commit/bcc566c2))
- [universal]: Fix changelog generation (#354) ([2e973c09](https://github.com/CloudPirates-io/helm-charts/commit/2e973c09))
- [mongodb] fix: newline between mongo labels and additional labels (#301) ([ea7937ff](https://github.com/CloudPirates-io/helm-charts/commit/ea7937ff))
- add tests for openshift (#226) ([c80c98ac](https://github.com/CloudPirates-io/helm-charts/commit/c80c98ac))
- [mongodb] feat: add metrics exporter (#243) ([c931978f](https://github.com/CloudPirates-io/helm-charts/commit/c931978f))

## [0.1.6] - 2025-10-09

- Update charts/zookeeper/values.yaml zookeeper to v3.9.4 (patch) (#267) ([df3b9e3e](https://github.com/CloudPirates-io/helm-charts/commit/df3b9e3e))

## [0.1.5] - 2025-10-01

- Fix/allow zookeeper to scale to 0 replicas (#196) ([7403e9da](https://github.com/CloudPirates-io/helm-charts/commit/7403e9da))
- trigger pipeline without version-upgrade (#191) ([819492c9](https://github.com/CloudPirates-io/helm-charts/commit/819492c9))

## [0.1.4] - 2025-09-30

- [Nginx] Change nginx and zookeeper security-context to use helper-function (#169) ([b581bc7c](https://github.com/CloudPirates-io/helm-charts/commit/b581bc7c))

## [0.1.3] - 2025-09-26

- #170 fix for command whitelist (#171) ([ebd91d87](https://github.com/CloudPirates-io/helm-charts/commit/ebd91d87))

## [0.1.2] - 2025-09-26

- [common] Fix/set securitycontext based on targetplatform to comply with openshift clusters (#166) ([f1bb75e7](https://github.com/CloudPirates-io/helm-charts/commit/f1bb75e7))

## [0.1.1] - 2025-09-25

- add networkpolicy and poddisruptionbudget (#2) (#155) ([2a84b435](https://github.com/CloudPirates-io/helm-charts/commit/2a84b435))

## [0.1.0] - 2025-09-11

- Initial release

